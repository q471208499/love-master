package com.love.constant;

public class Constant {
    public static final int DELAY_SHOW_BLUE_SNOW = 5;
    public static final int DELAY_SHOW_WEBVIEW_TIME = 5;
    public static final int IMAGE_HEIGHT = 64;
    public static final int IMAGE_WITH = 64;
}
