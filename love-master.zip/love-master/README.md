# love
程序员表白神器，程序员表白软件。程序员特有的求爱神器。程序员追女友利器=android+雪花效果+彩色气泡+心形花园



#APK下载（把这个给女朋友，她一定会高兴的）：
##http://download.csdn.net/detail/qiushi_1990/9476880

#表白效果图
![image](https://github.com/qiushi123/love/blob/master/I_Love_You_APP/loving.gif?raw=true)


![image](https://github.com/qiushi123/love/blob/master/I_Love_You_APP/qcl1_meitu_1.png?raw=true)



![image](https://github.com/qiushi123/love/blob/master/I_Love_You_APP/qcl2_meitu_2.png?raw=true)



![image](https://github.com/qiushi123/love/blob/master/I_Love_You_APP/qcl4.png?raw=true)


#百度手机助手下载地址：
##http://shouji.baidu.com/soft/item?docid=9156622&from=landing&f=search_app_I%20LOVE%20YOU%40list_11_title%409%40

#360手机助手下载地址
##http://zhushou.360.cn/detail/index/soft_id/3249940?recrefer=SE_D_I%20Love%20You


#我的个人博客
## http://blog.csdn.net/qiushi_1990


